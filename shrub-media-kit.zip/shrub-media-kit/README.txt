SHRUB — MEDIA KIT
=================

Files
-----
shrub-logo.png          The logo. Keep clear space around it of at least
                        half the logo's height, and don't recolour it.
shrub-mascot.webp       The hedgehog, on transparent background.
shrub-social-card.jpg   1200x630 card for link previews and posts.

Colours
-------
Yellow      #F4BB56     Accent. Headlines, buttons, highlights.
Ground      #151513     Background. Everything sits on this.
Light       #FFFFFF     Body text, at 55% opacity for secondary text.

Type
----
General Sans, by Indian Type Foundry. Free at fontshare.com.

Token
-----
SHRUB on Ethereum
0x3b991130eae3cca364406d718da22fa1c3e7c256

Always check the contract address against shrub.io before you trade or
share it. Tokens with the same name and a different address are not us.
